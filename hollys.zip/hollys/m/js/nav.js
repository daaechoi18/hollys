$('.main_nav').hide();
$('.sub_nav').hide();
$('.tgl_btn').click(function(){
  $('.main_nav').slideToggle(300);
});
$('.main_nav>li').click(function(){
  $(this).children('.sub_nav').slideToggle(300);
});