$('#close_1day').click(function(){
  $('.pop_win').hide(0);
});
$('#close').click(function(){
  $('.pop_win').hide();
});