$('.about_list').hide();
$('.about_box').click(function(){
  $('.about_list').slideToggle(300);
});
