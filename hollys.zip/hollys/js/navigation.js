$('.main_nav_sub').hide();
$('.main_nav>li').click(function(){
  $('.main_nav_sub').slideToggle(300);
});

