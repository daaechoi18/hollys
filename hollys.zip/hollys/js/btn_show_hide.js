// SHOW
$('#btn_more').click(function(){
  $('.item_list').css('height','350px');
  $('#btn_more').hide();
  $('#btn_close').show();
})

// HIDE
$('#btn_close').click(function(){
  $('.item_list').css('height','135px');
  $('#btn_close').hide();
  $('#btn_more').show();      
})