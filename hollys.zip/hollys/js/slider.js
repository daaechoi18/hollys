var mySwiper=new Swiper('.swiper-container', {
  loop:true,
  effect: 'fade',
  pagination:{el:'.swiper-pagination',
  clickable: true,
  },
  autoplay:{delay:5000,
  },
  speed:1500,
});